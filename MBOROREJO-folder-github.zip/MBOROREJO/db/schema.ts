import { sqliteTable, text, integer, primaryKey } from 'drizzle-orm/sqlite-core';
export const entries = sqliteTable('entries', {id:text('id').primaryKey(),kind:text('kind').notNull(),owner:text('owner').notNull(),status:text('status').notNull().default('pending'),data:text('data').notNull(),created:integer('created').notNull()});
export const reactions = sqliteTable('reactions',{post:text('post').notNull(),user:text('user').notNull(),value:integer('value').notNull() },t=>[primaryKey({columns:[t.post,t.user]})]);
export const settings = sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
