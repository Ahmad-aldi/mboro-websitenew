# MBOROREJO — Ruang Warga

Kode sumber website Dusun Mbororejo, Desa Ngrejeng, Kecamatan Grabagan, Kabupaten Tuban.

Website aktif: https://mbororejo-warga.akundataharian.chatgpt.site
Admin: https://mbororejo-warga.akundataharian.chatgpt.site/admin

## Penting sebelum mengunggah

Paket ini adalah **kode sumber aplikasi lengkap**, bukan satu file HTML statis.
Mengunggahnya ke repositori GitHub menyimpan kode; hal itu tidak otomatis
menjalankan website. **GitHub Pages tidak dapat menjalankan API, database,
login admin, atau penyimpanan foto aplikasi ini.** Website aktif di atas tetap
bisa digunakan dan tidak berubah setelah paket diunduh.

Untuk memindahkan hosting sepenuhnya, perlu menyiapkan server yang kompatibel,
database D1, penyimpanan R2, dan integrasi autentikasi tepercaya. Login saat ini
mengandalkan identitas yang diberikan platform Sites. Jangan sekadar meniru
header identitas pada server publik tanpa autentikasi yang memverifikasinya.

## Unggah manual ke GitHub

1. Ekstrak ZIP. Buka folder MBOROREJO.
2. Masuk ke akun GitHub Ahmad-aldi dan buat repositori `mbororejo`.
3. Unggah **isi** folder MBOROREJO ke akar repositori; jangan unggah ZIP saja.
4. Pertahankan susunan folder. Bila unggahan browser dibatasi, unggah beberapa
   kelompok file secara bertahap atau gunakan GitHub Desktop.
5. Simpan/commit unggahan. Periksa README.md, package.json, app/, public/, dan
   folder konfigurasi .openai/ ada di repositori.
6. Tambahkan URL website aktif pada bagian deskripsi/About repositori agar
   pengunjung repositori dapat membuka website.

GitHub: https://github.com/new
Panduan unggah: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository

## Fitur

- Halaman profil dusun, sejarah, alam, potensi, lokasi, dan kontak.
- Form nama pengunjung untuk sapaan di perangkat masing-masing.
- Direktori warga: nama, jenis kelamin, tempat/tanggal lahir, pekerjaan.
- Admin mengelola data dan mencatat persetujuan publikasi warga.
- Kiriman foto, komentar, buku tamu, dan laporan dengan moderasi.
- Satu pilihan suka/tidak suka untuk setiap akun pada setiap foto.
- Pengumuman, agenda, dan kabar.
- Editor profil/sejarah dan pilihan foto pembuka dari galeri yang disetujui.

## Struktur

- `app/page.tsx`: halaman publik.
- `app/admin/page.tsx`: panel pengelola.
- `app/globals.css`: tampilan dan animasi.
- `app/content.ts`: teks awal profil dan sejarah.
- `app/api/`: endpoint data, unggahan, dan penyajian foto.
- `app/server.ts`, `app/chatgpt-auth.ts`: integrasi server dan identitas.
- `public/`: gambar dan ikon.
- `db/`, `drizzle/`: skema dan migrasi database.
- `build/`, `scripts/`, `vite.config.ts`: konfigurasi build dan runtime.
- `tests/access.cjs`: pengujian aturan akses dengan database sementara.
- `.openai/hosting.json`: nama binding DB/BUCKET, tanpa identitas Site lama.

## Pengembangan lokal (untuk pengembang)

Gunakan Node.js >=22.13.0 dan pnpm sesuai versi pada package.json.

```sh
pnpm install --frozen-lockfile
pnpm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_cooing_lord_tyger.sql
pnpm run dev
```

Jalankan migrasi lokal di atas sekali pada database baru. Data lokal berbeda
dari data produksi. Build dari checkout bersih menggunakan profil portable.
Preview lokal starter memiliki simulasi login khusus loopback. Hak admin tetap
memerlukan konfigurasi runtime ADMIN_EMAIL; pada simulasi lokal, identitas
contohnya seedy@sites.test. Jangan gunakan identitas simulasi untuk produksi.

```sh
node tests/access.cjs
```

## Hosting dan data

Runtime memerlukan binding D1 `DB`, R2 `BUCKET`, serta secret `ADMIN_EMAIL`
yang diatur pada hosting. Nilai email pemilik dan kredensial tidak disertakan.
Jangan memasukkan token, password, atau secret ke kode maupun repositori publik.

Paket tidak berisi data warga, foto unggahan pengguna, cadangan database,
node_modules, .git, cache, atau hasil build. Foto lanskap bawaan adalah ilustrasi,
bukan foto dokumentasi Mbororejo, dan telah diberi keterangan pada website.

Sumber foto ilustrasi: https://images.unsplash.com/photo-1500382017468-9049fed747ef

## Status pemeriksaan

Kode aplikasi sebelumnya lolos build produksi dan pengujian aturan akses,
moderasi, persetujuan warga, privasi unggahan, reaksi tunggal, serta penghapusan
terkait. Paket ekspor diperiksa kelengkapannya; belum dideploy dari GitHub.
