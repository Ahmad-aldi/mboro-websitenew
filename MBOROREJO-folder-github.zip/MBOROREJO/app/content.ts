export const defaultProfile = {
 aboutTitle:'Sebuah tempat untuk pulang.',
 about:'Selamat datang di Dusun Mbororejo, bagian dari Desa Ngrejeng, Kecamatan Grabagan, Kabupaten Tuban. Website ini menjadi ruang untuk mengenal lingkungan dusun, berbagi informasi, dan mempererat hubungan antara warga dengan para pengunjung.\n\nMelalui ruang digital ini, cerita, foto, pengumuman, dan agenda warga dihimpun agar lebih mudah diakses bersama. Warga dapat ikut membagikan dokumentasi kegiatan dan momen sehari-hari melalui kiriman yang diperiksa oleh pengelola.\n\nMari merawat ruang ini dengan kabar yang bermanfaat dan sikap saling menghargai. Untuk yang tinggal dekat maupun yang sedang merantau, Mbororejo selalu punya cerita untuk dibagikan.',
 historyTitle:'Merawat ingatan, menyambung cerita.',
 history:'Sejarah Dusun Mbororejo merupakan bagian dari ingatan bersama yang perlu dihimpun dan dijaga. Halaman ini disiapkan untuk mendokumentasikan asal-usul nama, cerita para pendahulu, serta perjalanan dusun dari masa ke masa.\n\nCatatan sejarah sedang dihimpun bersama warga. Jika Anda memiliki foto lama, dokumen, atau cerita keluarga tentang Mbororejo, silakan menghubungi pengelola agar dapat diperiksa dan melengkapi halaman ini.',
 historyPublished:true,
 nature:'Lingkungan dan pertanian menyimpan banyak cerita. Bagian ini menjadi tempat mengenalkan potensi alam, hasil pertanian, dan usaha warga Mbororejo. Informasi akan dilengkapi oleh pengelola bersama warga.',
 heroImage:'',
};
export type Profile = typeof defaultProfile;
