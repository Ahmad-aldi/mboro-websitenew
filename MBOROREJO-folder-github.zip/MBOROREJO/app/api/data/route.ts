import {database,identity,json,sameOrigin,clean} from '../../server';
import {defaultProfile} from '../../content';
export const dynamic='force-dynamic';
export async function GET(req:Request){try{
 const {user,admin}=await identity();const db=database();const mode=new URL(req.url).searchParams.get('mode');
 if(mode==='admin'&&!admin)return json({error:'Akses hanya untuk pengelola.'},403);
 const rows=await db.prepare(mode==='admin'?"SELECT * FROM entries ORDER BY created DESC LIMIT 2000":"SELECT * FROM entries WHERE status='approved' AND kind IN ('resident','photo','comment','guest','news') ORDER BY created DESC LIMIT 2000").all();
 const setting=await db.prepare("SELECT value FROM settings WHERE key='profile'").first<{value:string}>();
 const counts=await db.prepare('SELECT post, SUM(CASE WHEN value=1 THEN 1 ELSE 0 END) AS likes, SUM(CASE WHEN value=-1 THEN 1 ELSE 0 END) AS dislikes FROM reactions GROUP BY post').all();
 const mine=user?await db.prepare('SELECT post,value FROM reactions WHERE user=?').bind(user.userId).all():{results:[]};
 let profile={...defaultProfile,...(setting?JSON.parse(setting.value):{})};if(mode!=='admin'&&!profile.historyPublished)profile={...profile,history:''};
 return json({entries:rows.results.map((r:any)=>({id:r.id,kind:r.kind,status:r.status,created:r.created,...JSON.parse(r.data)})),profile,reactions:counts.results,mine:mine.results,user:user?{name:user.fullName??'Warga',admin}:null});
}catch{return json({error:'Data belum dapat dimuat. Silakan coba lagi.'},500)}}
export async function POST(req:Request){try{
 if(!sameOrigin(req))return json({error:'Permintaan tidak diizinkan.'},403);
 const {user,admin}=await identity();if(!user)return json({error:'Silakan masuk terlebih dahulu.'},401);
 if(Number(req.headers.get('content-length')||0)>60000)return json({error:'Data terlalu besar.'},413);
 const raw=await req.text();if(raw.length>60000)return json({error:'Data terlalu besar.'},413);const body=JSON.parse(raw);const db=database();
 if(body.action==='profile'){
  if(!admin)return json({error:'Akses ditolak.'},403);let p=body.profile||{};
  const profile={aboutTitle:clean(p.aboutTitle,180),about:clean(p.about,14000),historyTitle:clean(p.historyTitle,180),history:clean(p.history,14000),historyPublished:!!p.historyPublished,nature:clean(p.nature,4000),heroImage:clean(p.heroImage,100)};
  if(profile.heroImage){const photo=await db.prepare("SELECT id FROM entries WHERE id=? AND kind='photo' AND status='approved'").bind(profile.heroImage).first();if(!photo)return json({error:'Pilih foto galeri yang telah disetujui.'},400)}
  await db.prepare("INSERT INTO settings(key,value) VALUES('profile',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(JSON.stringify(profile)).run();return json({ok:true});
 }
 if(['moderate','delete'].includes(body.action)){
  if(!admin)return json({error:'Akses ditolak.'},403);const row=await db.prepare('SELECT * FROM entries WHERE id=?').bind(clean(body.id)).first<any>();if(!row)return json({error:'Data tidak ditemukan.'},404);
  if(body.action==='delete'){await db.batch([db.prepare('DELETE FROM entries WHERE id=?').bind(row.id),db.prepare("DELETE FROM entries WHERE kind IN ('comment','report') AND json_extract(data,'$.post')=?").bind(row.id),db.prepare('DELETE FROM reactions WHERE post=?').bind(row.id)]);if(row.kind==='photo'){const {bucket}=await import('../../server');await bucket().delete(row.id)}}
  else {const status=body.status==='approved'?'approved':'rejected';if(row.kind==='resident'&&status==='approved'&&!JSON.parse(row.data).consent)return json({error:'Catat persetujuan warga terlebih dahulu.'},400);await db.prepare('UPDATE entries SET status=? WHERE id=?').bind(status,row.id).run()}
  return json({ok:true});
 }
 if(body.action==='reaction'){
  const post=clean(body.post);const exists=await db.prepare("SELECT id FROM entries WHERE id=? AND kind='photo' AND status='approved'").bind(post).first();if(!exists)return json({error:'Foto tidak ditemukan.'},404);
  const value=Number(body.value);if(![0,1,-1].includes(value))return json({error:'Reaksi tidak valid.'},400);
  if(!value)await db.prepare('DELETE FROM reactions WHERE post=? AND user=?').bind(post,user.userId).run();else await db.prepare('INSERT INTO reactions(post,user,value) VALUES(?,?,?) ON CONFLICT(post,user) DO UPDATE SET value=excluded.value').bind(post,user.userId,value).run();return json({ok:true});
 }
 const kind=body.kind;let data:any={};let status='pending';const id=clean(body.id)||crypto.randomUUID();
 if(kind==='resident'){
  if(!admin)return json({error:'Akses ditolak.'},403);const d=body.data||{};data={name:clean(d.name,120),gender:clean(d.gender,30),birthplace:clean(d.birthplace,100),birthday:clean(d.birthday,10),job:clean(d.job,100),consent:!!d.consent};
  if(!data.name||!['Laki-laki','Perempuan'].includes(data.gender)||!data.birthplace||!/^\d{4}-\d{2}-\d{2}$/.test(data.birthday)||!Number.isFinite(Date.parse(data.birthday))||new Date(data.birthday)>new Date()||!data.job)return json({error:'Lengkapi data warga dengan tanggal lahir yang valid.'},400);
  status=d.published&&data.consent?'approved':'pending';
 }else if(kind==='news'){
  if(!admin)return json({error:'Akses ditolak.'},403);const d=body.data||{};data={title:clean(d.title,160),text:clean(d.text,6000),category:['Pengumuman','Agenda','Kabar'].includes(d.category)?d.category:'Kabar',date:clean(d.date,30)};if(!data.title||!data.text)return json({error:'Judul dan isi wajib diisi.'},400);status=d.published?'approved':'pending';
 }else if(['comment','guest','report'].includes(kind)){
  const recent=await db.prepare("SELECT COUNT(*) AS n FROM entries WHERE owner=? AND created>?").bind(user.userId,Date.now()-3600000).first<{n:number}>();if((recent?.n||0)>=30&&!admin)return json({error:'Batas kiriman per jam tercapai. Coba lagi nanti.'},429);
  data={name:clean(body.data?.name,80)||user.fullName||'Pengunjung',text:clean(body.data?.text,1500),post:clean(body.data?.post),origin:clean(body.data?.origin,100)};
  if(!data.text)return json({error:'Pesan wajib diisi.'},400);
  if(kind==='comment'){const post=await db.prepare("SELECT id FROM entries WHERE id=? AND kind='photo' AND status='approved'").bind(data.post).first();if(!post)return json({error:'Foto tidak tersedia.'},404)}
 }else return json({error:'Jenis data tidak dikenal.'},400);
 if(body.id){if(!admin)return json({error:'Akses ditolak.'},403);const old=await db.prepare('SELECT kind FROM entries WHERE id=?').bind(id).first<any>();if(!old||old.kind!==kind)return json({error:'Data tidak ditemukan.'},404);await db.prepare('UPDATE entries SET data=?,status=? WHERE id=?').bind(JSON.stringify(data),status,id).run()}
 else await db.prepare('INSERT INTO entries(id,kind,owner,status,data,created) VALUES(?,?,?,?,?,?)').bind(id,kind,user.userId,status,JSON.stringify(data),Date.now()).run();
 return json({ok:true});
}catch{return json({error:'Perubahan belum tersimpan. Periksa isian dan coba lagi.'},400)}}
