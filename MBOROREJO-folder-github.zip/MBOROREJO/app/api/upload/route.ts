import {identity,database,bucket,json,clean,sameOrigin} from '../../server';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{
 if(!sameOrigin(req))return json({error:'Permintaan ditolak.'},403);const {user,admin}=await identity();if(!user)return json({error:'Masuk untuk mengirim foto.'},401);
 if(Number(req.headers.get('content-length')||0)>6500000)return json({error:'Ukuran foto maksimal 5 MB.'},413);
 const recent=await database().prepare("SELECT COUNT(*) n FROM entries WHERE owner=? AND kind='photo' AND created>?").bind(user.userId,Date.now()-86400000).first<{n:number}>();if((recent?.n||0)>=10&&!admin)return json({error:'Maksimal 10 foto per hari.'},429);
 const form=await req.formData();const file=form.get('file');if(!(file instanceof File)||!file.size||file.size>5*1024*1024)return json({error:'Pilih foto JPG, PNG, atau WebP maksimal 5 MB.'},400);
 const bytes=new Uint8Array(await file.arrayBuffer());let mime='';if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)mime='image/jpeg';else if(bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71)mime='image/png';else if(new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP')mime='image/webp';if(!mime)return json({error:'Format foto tidak didukung.'},400);
 const title=clean(form.get('title'),160);if(!title||form.get('consent')!=='true')return json({error:'Judul dan persetujuan publikasi wajib diisi.'},400);
 const id=crypto.randomUUID();const data={title,text:clean(form.get('text'),1500),name:clean(form.get('name'),80)||user.fullName||'Warga Mbororejo',category:clean(form.get('category'),60)||'Cerita warga',mime};
 await bucket().put(id,bytes,{httpMetadata:{contentType:mime}});
 try{await database().prepare('INSERT INTO entries(id,kind,owner,status,data,created) VALUES(?,?,?,?,?,?)').bind(id,'photo',user.userId,'pending',JSON.stringify(data),Date.now()).run()}catch(e){await bucket().delete(id);throw e}
 return json({ok:true});
}catch{return json({error:'Foto belum terkirim. Silakan coba kembali.'},500)}}
