import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'MBOROREJO — Dekat di hati, hangat dalam cerita',description:'Ruang berbagi warga Dusun Mbororejo, Desa Ngrejeng, Kecamatan Grabagan, Tuban. Kenali dusun, temukan cerita, dan ikut berbagi.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="id"><body>{children}</body></html>}
