import { env } from 'cloudflare:workers';
import { getChatGPTUser } from './chatgpt-auth';
export const database=()=>{const db=env.DB;if(!db)throw new Error('Database belum tersedia');return db};
export const bucket=()=>{const b=env.BUCKET;if(!b)throw new Error('Penyimpanan belum tersedia');return b};
export async function identity(){const u=await getChatGPTUser();const adminEmail=(env as unknown as {ADMIN_EMAIL?:string}).ADMIN_EMAIL;return {user:u,admin:!!(u&&adminEmail&&u.email.toLowerCase()===adminEmail.toLowerCase())};}
export const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export function sameOrigin(req:Request){const origin=req.headers.get('origin');return !!origin&&origin===new URL(req.url).origin;}
export function clean(value:unknown,max=300){return typeof value==='string'?value.trim().slice(0,max):'';}
